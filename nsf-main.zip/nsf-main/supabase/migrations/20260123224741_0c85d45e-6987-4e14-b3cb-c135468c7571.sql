-- Create indexes on branch_id columns for optimal performance with 100+ branches
-- These indexes ensure fast filtering and joins even with concurrent operations

-- Index on products.branch_id
CREATE INDEX IF NOT EXISTS idx_products_branch_id ON public.products(branch_id);

-- Index on billing_records.branch_id  
CREATE INDEX IF NOT EXISTS idx_billing_records_branch_id ON public.billing_records(branch_id);

-- Index on quotations.branch_id
CREATE INDEX IF NOT EXISTS idx_quotations_branch_id ON public.quotations(branch_id);

-- Index on orders.branch_id
CREATE INDEX IF NOT EXISTS idx_orders_branch_id ON public.orders(branch_id);

-- Composite indexes for common queries
-- Products by branch and active status
CREATE INDEX IF NOT EXISTS idx_products_branch_active ON public.products(branch_id, is_active);

-- Orders by branch and status
CREATE INDEX IF NOT EXISTS idx_orders_branch_status ON public.orders(branch_id, status);

-- Bills by branch and date
CREATE INDEX IF NOT EXISTS idx_billing_records_branch_date ON public.billing_records(branch_id, created_at DESC);

-- Quotations by branch and status
CREATE INDEX IF NOT EXISTS idx_quotations_branch_status ON public.quotations(branch_id, status);