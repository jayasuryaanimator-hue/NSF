-- Add 'branch_manager' to app_role enum (this needs its own transaction)
ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'branch_manager';