-- Create return_messages table for communication between customer and admin
CREATE TABLE public.return_messages (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  return_id UUID NOT NULL REFERENCES public.returns(id) ON DELETE CASCADE,
  sender_type TEXT NOT NULL CHECK (sender_type IN ('customer', 'admin')),
  sender_id UUID NOT NULL,
  message TEXT NOT NULL,
  is_read BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.return_messages ENABLE ROW LEVEL SECURITY;

-- RLS Policies for return_messages

-- Customers can view messages on their own returns
CREATE POLICY "Customers can view their return messages"
ON public.return_messages
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM public.returns
    WHERE returns.id = return_messages.return_id
    AND returns.user_id = auth.uid()
  )
);

-- Customers can send messages on their own returns
CREATE POLICY "Customers can send messages on their returns"
ON public.return_messages
FOR INSERT
WITH CHECK (
  sender_type = 'customer'
  AND sender_id = auth.uid()
  AND EXISTS (
    SELECT 1 FROM public.returns
    WHERE returns.id = return_messages.return_id
    AND returns.user_id = auth.uid()
  )
);

-- Admins can view all return messages
CREATE POLICY "Admins can view all return messages"
ON public.return_messages
FOR SELECT
USING (has_role(auth.uid(), 'admin'::app_role));

-- Admins can send messages
CREATE POLICY "Admins can send return messages"
ON public.return_messages
FOR INSERT
WITH CHECK (
  sender_type = 'admin'
  AND has_role(auth.uid(), 'admin'::app_role)
);

-- Admins can update messages (mark as read)
CREATE POLICY "Admins can update return messages"
ON public.return_messages
FOR UPDATE
USING (has_role(auth.uid(), 'admin'::app_role));

-- Admins can delete messages
CREATE POLICY "Admins can delete return messages"
ON public.return_messages
FOR DELETE
USING (has_role(auth.uid(), 'admin'::app_role));

-- Create index for faster lookups
CREATE INDEX idx_return_messages_return_id ON public.return_messages(return_id);
CREATE INDEX idx_return_messages_created_at ON public.return_messages(created_at);