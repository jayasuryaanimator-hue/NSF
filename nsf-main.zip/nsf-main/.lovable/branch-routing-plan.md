# Path-Based Branch Routing System

## Overview
Each branch has its own URL namespace with isolated data:
- `/edp/` - Edappadi branch storefront
- `/edp/shop` - Edappadi product catalog
- `/edp/admin` - Edappadi admin panel
- `/nmk/` - Namakkal branch storefront
- `/krr/` - Karur branch storefront

## Current Implementation Status ✅

### Completed Features
1. **Branch URL Slugs** - Each branch has a configurable URL slug
2. **Branch Routes** - Routes configured in App.tsx for `/:branchSlug/*`
3. **Branch Storefront** - BranchIndex and BranchShop components
4. **Branch Admin** - Branch-specific admin panel with BranchRouteGuard
5. **URL Management UI** - Branch management shows URLs with copy/open buttons
6. **Data Isolation** - Products, billing, orders filtered by branch_id

### Data Isolation Rules
| Data Type | Branch Can View | Branch Can Edit |
|-----------|-----------------|-----------------|
| Own Products | ✅ | ✅ |
| Own Billing | ✅ | ✅ (no delete) |
| Own Quotations | ✅ | ✅ (no delete) |
| Own Orders | ✅ | ✅ (no delete) |
| Overall Stock | ✅ All branches | ❌ |
| Other Branch Data | ❌ | ❌ |

---

## Architecture

### URL Structure
```
/                           → Main website (no branch context)
/shop                       → Global shop
/admin                      → Global admin panel (main admin only)

/:branchSlug/               → Branch storefront home
/:branchSlug/shop           → Branch product catalog
/:branchSlug/product/:slug  → Product detail (branch context)
/:branchSlug/cart           → Branch cart
/:branchSlug/checkout       → Branch checkout
/:branchSlug/admin          → Branch admin panel
/:branchSlug/admin/products → Branch product management
/:branchSlug/admin/billing  → Branch billing
/:branchSlug/admin/orders   → Branch orders
```

### Access Control Matrix

| Route | Main Admin | Branch Manager | Customer |
|-------|-----------|----------------|----------|
| `/admin/*` | ✅ Full access | ❌ Redirected | ❌ Redirected |
| `/` (storefront) | ❌ Redirected to /admin | ✅ | ✅ |
| `/:branchSlug/admin/*` | ✅ Full access | ✅ Own branch only | ❌ Redirected |
| `/:branchSlug/*` (storefront) | ❌ Redirected | ✅ | ✅ |

---

## Implementation Plan

### Phase 1: Database Updates
**Already Complete:**
- `branches` table has `slug` column
- `branch_users` links managers to branches
- `branch_credentials` stores encrypted passwords

### Phase 2: Enhanced Branch Context
**File: `src/contexts/BranchContext.tsx`**
1. Detect branch from URL path segment
2. Load branch data when slug changes
3. Provide branch-aware navigation helpers

### Phase 3: Route Guards

**3.1 AdminRouteGuard (exists - enhance)**
- Redirect pure admins from customer routes to `/admin`
- Allow branch managers and customers to access storefronts

**3.2 BranchRouteGuard (exists - enhance)**
- Validate branch manager access to their specific branch admin
- Allow main admins to access any branch admin
- Redirect unauthorized users

**3.3 BranchCustomerGuard (new)**
- Validate branch exists
- Show 404 for invalid branch slugs

### Phase 4: Branch-Specific Pages

**4.1 Branch Storefront Pages**
```
src/pages/branch/
├── BranchIndex.tsx      → Branch home (exists)
├── BranchShop.tsx       → Branch catalog (exists)
├── BranchProductDetail.tsx → Product with branch context
├── BranchCart.tsx       → Cart for branch purchases
├── BranchCheckout.tsx   → Checkout with branch info
└── BranchAdmin.tsx      → Branch admin wrapper (exists)
```

**4.2 Branch Admin Features**
Branch managers can access:
- Products (their branch only)
- Orders (their branch only)
- Billing (create bills)
- Quotations (create quotes)
- Stock (view stock levels)
- Stock Transfers (request transfers)

Branch managers CANNOT:
- Delete products/orders/bills (admin only)
- Access other branches
- Manage users/categories/settings

### Phase 5: Navigation Updates

**5.1 Header Component**
- Show branch name in header when on branch route
- Adjust navigation links to include branch prefix

**5.2 Admin Sidebar**
- Differentiate between global admin and branch admin views
- Hide restricted items for branch managers

---

## Component Architecture

### BranchLayout Wrapper
```tsx
<BranchProvider>
  <BranchLayout>
    <Header branchContext={branch} />
    <main>{children}</main>
    <Footer />
  </BranchLayout>
</BranchProvider>
```

### Route Configuration
```tsx
// Customer routes - wrapped with AdminRouteGuard
<Route path="/" element={<AdminRouteGuard><Index /></AdminRouteGuard>} />

// Branch customer routes
<Route path="/:branchSlug" element={<BranchLayout><BranchIndex /></BranchLayout>} />
<Route path="/:branchSlug/shop" element={<BranchLayout><BranchShop /></BranchLayout>} />

// Branch admin routes
<Route path="/:branchSlug/admin" element={<BranchAdmin />}>
  <Route index element={<BranchManagerDashboard />} />
  <Route path="products" element={<Products />} />
  <Route path="billing" element={<Billing />} />
</Route>

// Global admin routes
<Route path="/admin" element={<AdminLayout />}>
  <Route index element={<Dashboard />} />
  <Route path="branches" element={<BranchManagement />} />
</Route>
```

---

## Data Isolation

### Products
- Each product has `branch_id` (nullable for global products)
- Branch managers only see/edit their branch products
- Main admin sees all products with branch filter

### Orders
- Orders have `branch_id` for branch-specific purchases
- Branch managers see orders from their branch only
- Global orders (branch_id = null) visible to main admin only

### Billing & Quotations
- Created with `branch_id` from context
- Branch managers can only view/edit their branch records
- Delete restricted to main admin

---

## Security Considerations

1. **RLS Policies**
   - Products: Branch managers can SELECT/INSERT/UPDATE where branch_id matches
   - Orders: Branch managers can SELECT/UPDATE where branch_id matches
   - Billing: Branch managers can SELECT/INSERT/UPDATE their branch
   - DELETE operations: Admin only via has_role check

2. **Route Guards**
   - Server-side verification via RLS
   - Client-side guards for UX (redirect unauthorized users quickly)

3. **API Validation**
   - Edge functions verify caller's branch assignment
   - Prevent cross-branch data access

---

## Migration Path

### Step 1: Current State → Enhanced Guards
- Update AdminRouteGuard to properly redirect pure admins
- Enhance BranchRouteGuard for stricter validation

### Step 2: Branch Storefront Enhancement
- Add BranchCart and BranchCheckout components
- Update Header/Footer for branch context

### Step 3: Admin Panel Polish
- Conditional sidebar items based on role
- Branch-specific dashboard metrics

### Step 4: Testing & Validation
- Test all access scenarios
- Verify data isolation
- Performance testing with multiple branches

---

## Files to Modify

| File | Changes |
|------|---------|
| `src/App.tsx` | Already configured with branch routes |
| `src/components/AdminRouteGuard.tsx` | Enhance redirect logic |
| `src/components/BranchRouteGuard.tsx` | Stricter validation |
| `src/components/layout/Header.tsx` | Branch-aware navigation |
| `src/components/admin/AdminLayout.tsx` | Role-based sidebar |
| `src/pages/admin/Billing.tsx` | Delete button visibility |
| `src/pages/admin/Quotations.tsx` | Delete button visibility |

---

## Success Criteria

1. ✅ Branch URLs work: `/edappadi/shop`, `/namakkal/admin`
2. ✅ Pure admins redirected from storefronts to `/admin`
3. ✅ Branch managers can only access their assigned branch
4. ✅ Delete buttons hidden for non-admin users
5. ✅ Data isolation: branch managers see only their data
6. ✅ Main admin has full access to all branches
