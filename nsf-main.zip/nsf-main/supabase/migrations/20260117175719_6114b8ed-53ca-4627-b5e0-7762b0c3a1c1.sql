-- Enable realtime for orders table to allow live status updates
ALTER PUBLICATION supabase_realtime ADD TABLE public.orders;