-- Create branches table
CREATE TABLE public.branches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  code text NOT NULL UNIQUE,
  address_line1 text NOT NULL,
  address_line2 text,
  city text NOT NULL,
  state text NOT NULL DEFAULT 'Tamil Nadu',
  postal_code text NOT NULL,
  phone text NOT NULL,
  email text,
  instagram_url text,
  map_embed_url text,
  is_active boolean DEFAULT true,
  display_order integer DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Create branch_users table (assigns users to branches)
CREATE TABLE public.branch_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  branch_id uuid REFERENCES public.branches(id) ON DELETE CASCADE NOT NULL,
  user_id uuid NOT NULL,
  is_primary boolean DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(branch_id, user_id)
);

-- Add branch_id to existing tables
ALTER TABLE public.products ADD COLUMN branch_id uuid REFERENCES public.branches(id) ON DELETE SET NULL;
ALTER TABLE public.billing_records ADD COLUMN branch_id uuid REFERENCES public.branches(id) ON DELETE SET NULL;
ALTER TABLE public.quotations ADD COLUMN branch_id uuid REFERENCES public.branches(id) ON DELETE SET NULL;
ALTER TABLE public.orders ADD COLUMN branch_id uuid REFERENCES public.branches(id) ON DELETE SET NULL;

-- Enable RLS on new tables
ALTER TABLE public.branches ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.branch_users ENABLE ROW LEVEL SECURITY;

-- Function to check if user is branch manager for a specific branch
CREATE OR REPLACE FUNCTION public.is_branch_manager(_user_id uuid, _branch_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.branch_users bu
    JOIN public.user_roles ur ON ur.user_id = bu.user_id
    WHERE bu.user_id = _user_id
      AND bu.branch_id = _branch_id
      AND ur.role = 'branch_manager'
  )
$$;

-- Function to get user's branch id
CREATE OR REPLACE FUNCTION public.get_user_branch_id(_user_id uuid)
RETURNS uuid
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT branch_id
  FROM public.branch_users
  WHERE user_id = _user_id
  LIMIT 1
$$;

-- RLS Policies for branches table
CREATE POLICY "Admins can manage branches"
  ON public.branches FOR ALL
  USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "Branch managers can view their branch"
  ON public.branches FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.branch_users
      WHERE branch_users.branch_id = branches.id
      AND branch_users.user_id = auth.uid()
    )
  );

CREATE POLICY "Anyone can view active branches"
  ON public.branches FOR SELECT
  USING (is_active = true);

-- RLS Policies for branch_users table
CREATE POLICY "Admins can manage branch users"
  ON public.branch_users FOR ALL
  USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "Users can view their branch assignment"
  ON public.branch_users FOR SELECT
  USING (user_id = auth.uid());

-- Update products RLS to include branch access
DROP POLICY IF EXISTS "Admins can manage products" ON public.products;
DROP POLICY IF EXISTS "Admins can view all products" ON public.products;

CREATE POLICY "Admins can manage all products"
  ON public.products FOR ALL
  USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "Branch managers can view their branch products"
  ON public.products FOR SELECT
  USING (
    branch_id IS NOT NULL AND is_branch_manager(auth.uid(), branch_id)
  );

CREATE POLICY "Branch managers can insert products"
  ON public.products FOR INSERT
  WITH CHECK (
    branch_id IS NOT NULL AND is_branch_manager(auth.uid(), branch_id)
  );

CREATE POLICY "Branch managers can update their products"
  ON public.products FOR UPDATE
  USING (
    branch_id IS NOT NULL AND is_branch_manager(auth.uid(), branch_id)
  );

-- Update billing_records RLS
DROP POLICY IF EXISTS "Admins can manage billing records" ON public.billing_records;

CREATE POLICY "Admins can manage all billing records"
  ON public.billing_records FOR ALL
  USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "Branch managers can view their bills"
  ON public.billing_records FOR SELECT
  USING (
    branch_id IS NOT NULL AND is_branch_manager(auth.uid(), branch_id)
  );

CREATE POLICY "Branch managers can create bills"
  ON public.billing_records FOR INSERT
  WITH CHECK (
    branch_id IS NOT NULL AND is_branch_manager(auth.uid(), branch_id)
  );

CREATE POLICY "Branch managers can update their bills"
  ON public.billing_records FOR UPDATE
  USING (
    branch_id IS NOT NULL AND is_branch_manager(auth.uid(), branch_id)
  );

-- Update quotations RLS
DROP POLICY IF EXISTS "Admins can manage quotations" ON public.quotations;

CREATE POLICY "Admins can manage all quotations"
  ON public.quotations FOR ALL
  USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "Branch managers can view their quotations"
  ON public.quotations FOR SELECT
  USING (
    branch_id IS NOT NULL AND is_branch_manager(auth.uid(), branch_id)
  );

CREATE POLICY "Branch managers can create quotations"
  ON public.quotations FOR INSERT
  WITH CHECK (
    branch_id IS NOT NULL AND is_branch_manager(auth.uid(), branch_id)
  );

CREATE POLICY "Branch managers can update their quotations"
  ON public.quotations FOR UPDATE
  USING (
    branch_id IS NOT NULL AND is_branch_manager(auth.uid(), branch_id)
  );

-- Update orders RLS for branch access
CREATE POLICY "Branch managers can view their branch orders"
  ON public.orders FOR SELECT
  USING (
    branch_id IS NOT NULL AND is_branch_manager(auth.uid(), branch_id)
  );

CREATE POLICY "Branch managers can update their branch orders"
  ON public.orders FOR UPDATE
  USING (
    branch_id IS NOT NULL AND is_branch_manager(auth.uid(), branch_id)
  );

-- Add trigger for updated_at on branches
CREATE TRIGGER update_branches_updated_at
  BEFORE UPDATE ON public.branches
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Create branch summary views
CREATE OR REPLACE VIEW public.branch_stock_summary AS
SELECT 
  b.id as branch_id,
  b.name as branch_name,
  b.code as branch_code,
  COUNT(p.id) as total_products,
  COALESCE(SUM(p.stock_quantity), 0) as total_units,
  COALESCE(SUM(COALESCE(p.cost_price, p.price) * COALESCE(p.stock_quantity, 0)), 0) as total_cost_value,
  COALESCE(SUM(p.price * COALESCE(p.stock_quantity, 0)), 0) as total_retail_value,
  COUNT(CASE WHEN COALESCE(p.stock_quantity, 0) = 0 THEN 1 END) as out_of_stock_count,
  COUNT(CASE WHEN COALESCE(p.stock_quantity, 0) > 0 AND COALESCE(p.stock_quantity, 0) <= 5 THEN 1 END) as low_stock_count
FROM public.branches b
LEFT JOIN public.products p ON p.branch_id = b.id AND p.is_active = true
WHERE b.is_active = true
GROUP BY b.id, b.name, b.code;

CREATE OR REPLACE VIEW public.branch_billing_summary AS
SELECT 
  b.id as branch_id,
  b.name as branch_name,
  b.code as branch_code,
  COUNT(br.id) as total_bills,
  COALESCE(SUM(br.total_amount), 0) as total_amount,
  COALESCE(SUM(br.subtotal), 0) as total_subtotal,
  COALESCE(SUM(br.tax_amount), 0) as total_tax,
  COALESCE(SUM(br.discount_amount), 0) as total_discounts
FROM public.branches b
LEFT JOIN public.billing_records br ON br.branch_id = b.id
WHERE b.is_active = true
GROUP BY b.id, b.name, b.code;

CREATE OR REPLACE VIEW public.branch_quotations_summary AS
SELECT 
  b.id as branch_id,
  b.name as branch_name,
  b.code as branch_code,
  COUNT(q.id) as total_quotations,
  COUNT(CASE WHEN q.status = 'draft' THEN 1 END) as draft_count,
  COUNT(CASE WHEN q.status = 'sent' THEN 1 END) as sent_count,
  COUNT(CASE WHEN q.status = 'accepted' THEN 1 END) as accepted_count,
  COUNT(CASE WHEN q.status = 'rejected' THEN 1 END) as rejected_count,
  COALESCE(SUM(q.total_amount), 0) as total_value
FROM public.branches b
LEFT JOIN public.quotations q ON q.branch_id = b.id
WHERE b.is_active = true
GROUP BY b.id, b.name, b.code;

CREATE OR REPLACE VIEW public.branch_orders_summary AS
SELECT 
  b.id as branch_id,
  b.name as branch_name,
  b.code as branch_code,
  COUNT(o.id) as total_orders,
  COUNT(CASE WHEN o.status = 'delivered' THEN 1 END) as delivered_count,
  COUNT(CASE WHEN o.status NOT IN ('delivered', 'cancelled') THEN 1 END) as pending_count,
  COUNT(CASE WHEN o.status = 'cancelled' THEN 1 END) as cancelled_count,
  COALESCE(SUM(CASE WHEN o.status = 'delivered' AND o.payment_status = 'verified' THEN o.total_amount ELSE 0 END), 0) as total_sales
FROM public.branches b
LEFT JOIN public.orders o ON o.branch_id = b.id
WHERE b.is_active = true
GROUP BY b.id, b.name, b.code;