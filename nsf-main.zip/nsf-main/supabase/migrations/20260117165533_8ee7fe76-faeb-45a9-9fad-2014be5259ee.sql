-- Create storage bucket for page content images
INSERT INTO storage.buckets (id, name, public)
VALUES ('page-images', 'page-images', true)
ON CONFLICT (id) DO NOTHING;

-- Allow admins to upload images
CREATE POLICY "Admins can upload page images"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'page-images' 
  AND has_role(auth.uid(), 'admin'::app_role)
);

-- Allow admins to update images
CREATE POLICY "Admins can update page images"
ON storage.objects FOR UPDATE
USING (
  bucket_id = 'page-images' 
  AND has_role(auth.uid(), 'admin'::app_role)
);

-- Allow admins to delete images
CREATE POLICY "Admins can delete page images"
ON storage.objects FOR DELETE
USING (
  bucket_id = 'page-images' 
  AND has_role(auth.uid(), 'admin'::app_role)
);

-- Allow anyone to view page images (public bucket)
CREATE POLICY "Anyone can view page images"
ON storage.objects FOR SELECT
USING (bucket_id = 'page-images');