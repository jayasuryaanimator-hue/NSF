-- Create branch_credentials table for storing encrypted passwords (admin viewable)
CREATE TABLE public.branch_credentials (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  branch_id UUID NOT NULL REFERENCES public.branches(id) ON DELETE CASCADE,
  user_id UUID NOT NULL,
  encrypted_password TEXT NOT NULL,
  email TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(branch_id),
  UNIQUE(user_id)
);

-- Enable RLS
ALTER TABLE public.branch_credentials ENABLE ROW LEVEL SECURITY;

-- Admin-only access policy
CREATE POLICY "Admins can manage branch credentials"
ON public.branch_credentials
FOR ALL
USING (public.has_role(auth.uid(), 'admin'));

-- Create trigger for updated_at
CREATE TRIGGER update_branch_credentials_updated_at
BEFORE UPDATE ON public.branch_credentials
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Drop and recreate FK constraints with CASCADE DELETE for products
ALTER TABLE public.products DROP CONSTRAINT IF EXISTS products_branch_id_fkey;
ALTER TABLE public.products ADD CONSTRAINT products_branch_id_fkey 
  FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON DELETE CASCADE;

-- Drop and recreate FK constraints with CASCADE DELETE for billing_records
ALTER TABLE public.billing_records DROP CONSTRAINT IF EXISTS billing_records_branch_id_fkey;
ALTER TABLE public.billing_records ADD CONSTRAINT billing_records_branch_id_fkey 
  FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON DELETE CASCADE;

-- Drop and recreate FK constraints with CASCADE DELETE for orders
ALTER TABLE public.orders DROP CONSTRAINT IF EXISTS orders_branch_id_fkey;
ALTER TABLE public.orders ADD CONSTRAINT orders_branch_id_fkey 
  FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON DELETE CASCADE;

-- Drop and recreate FK constraints with CASCADE DELETE for quotations
ALTER TABLE public.quotations DROP CONSTRAINT IF EXISTS quotations_branch_id_fkey;
ALTER TABLE public.quotations ADD CONSTRAINT quotations_branch_id_fkey 
  FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON DELETE CASCADE;

-- Drop and recreate FK constraints with CASCADE DELETE for branch_users
ALTER TABLE public.branch_users DROP CONSTRAINT IF EXISTS branch_users_branch_id_fkey;
ALTER TABLE public.branch_users ADD CONSTRAINT branch_users_branch_id_fkey 
  FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON DELETE CASCADE;

-- Drop and recreate FK constraints with CASCADE DELETE for stock_transfers (from_branch)
ALTER TABLE public.stock_transfers DROP CONSTRAINT IF EXISTS stock_transfers_from_branch_id_fkey;
ALTER TABLE public.stock_transfers ADD CONSTRAINT stock_transfers_from_branch_id_fkey 
  FOREIGN KEY (from_branch_id) REFERENCES public.branches(id) ON DELETE CASCADE;

-- Drop and recreate FK constraints with CASCADE DELETE for stock_transfers (to_branch)
ALTER TABLE public.stock_transfers DROP CONSTRAINT IF EXISTS stock_transfers_to_branch_id_fkey;
ALTER TABLE public.stock_transfers ADD CONSTRAINT stock_transfers_to_branch_id_fkey 
  FOREIGN KEY (to_branch_id) REFERENCES public.branches(id) ON DELETE CASCADE;

-- Drop and recreate FK constraints with CASCADE DELETE for damaged_stock
ALTER TABLE public.damaged_stock DROP CONSTRAINT IF EXISTS damaged_stock_branch_id_fkey;
ALTER TABLE public.damaged_stock ADD CONSTRAINT damaged_stock_branch_id_fkey 
  FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON DELETE CASCADE;

ALTER TABLE public.damaged_stock DROP CONSTRAINT IF EXISTS damaged_stock_from_branch_id_fkey;
ALTER TABLE public.damaged_stock ADD CONSTRAINT damaged_stock_from_branch_id_fkey 
  FOREIGN KEY (from_branch_id) REFERENCES public.branches(id) ON DELETE CASCADE;