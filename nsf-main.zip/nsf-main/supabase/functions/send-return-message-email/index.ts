import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.90.1";

const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY");

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

interface EmailRequest {
  returnId: string;
  message: string;
  senderType: 'customer' | 'admin';
}

const handler = async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { returnId, message, senderType }: EmailRequest = await req.json();

    if (!RESEND_API_KEY) {
      console.log("RESEND_API_KEY not configured, skipping email");
      return new Response(
        JSON.stringify({ message: "Email service not configured" }),
        { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    // Create Supabase client with service role
    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    // Get return details with order info
    const { data: returnData, error: returnError } = await supabaseAdmin
      .from('returns')
      .select(`
        *,
        orders (
          order_number,
          user_id,
          shipping_address
        )
      `)
      .eq('id', returnId)
      .single();

    if (returnError || !returnData) {
      console.error('Error fetching return:', returnError);
      return new Response(
        JSON.stringify({ error: 'Return not found' }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Get user's profile for email
    const { data: profile, error: profileError } = await supabaseAdmin
      .from('profiles')
      .select('email, full_name')
      .eq('user_id', returnData.user_id)
      .single();

    if (profileError || !profile?.email) {
      console.error('Error fetching profile:', profileError);
      return new Response(
        JSON.stringify({ error: 'User profile not found' }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const orderNumber = returnData.orders?.order_number || 'Unknown';
    const customerName = profile.full_name || 'Customer';
    const customerEmail = profile.email;

    // Determine recipient based on sender type
    let recipientEmail: string;
    let subject: string;
    let htmlContent: string;

    if (senderType === 'admin') {
      // Admin sent message, notify customer
      recipientEmail = customerEmail;
      subject = `New message about your return request - Order ${orderNumber}`;
      htmlContent = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <div style="background: linear-gradient(135deg, #059669 0%, #047857 100%); color: white; padding: 20px; border-radius: 8px 8px 0 0; text-align: center;">
            <h1 style="margin: 0; font-size: 20px;">New Sathiya Furniture</h1>
          </div>
          <div style="background-color: white; padding: 24px; border: 1px solid #e5e7eb; border-top: none; border-radius: 0 0 8px 8px;">
            <h2 style="color: #166534; margin-top: 0;">New Message About Your Return Request</h2>
            <p>Hello ${customerName},</p>
            <p>You have received a new message from our support team regarding your return request for order <strong>${orderNumber}</strong>.</p>
            
            <div style="background-color: #f3f4f6; padding: 16px; border-radius: 8px; margin: 20px 0;">
              <p style="margin: 0; color: #374151;"><strong>Message:</strong></p>
              <p style="margin: 8px 0 0 0; color: #4b5563;">${message}</p>
            </div>
            
            <p>Please log in to your account to view the full conversation and reply.</p>
            
            <p style="margin-top: 24px;">Best regards,<br>New Sathiya Furniture Support Team</p>
          </div>
        </div>
      `;
    } else {
      // Customer sent message, notify admin
      recipientEmail = 'krameshjet@gmail.com';
      subject = `New customer message - Return for Order ${orderNumber}`;
      htmlContent = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <div style="background: linear-gradient(135deg, #059669 0%, #047857 100%); color: white; padding: 20px; border-radius: 8px 8px 0 0; text-align: center;">
            <h1 style="margin: 0; font-size: 20px;">New Sathiya Furniture - Admin Alert</h1>
          </div>
          <div style="background-color: white; padding: 24px; border: 1px solid #e5e7eb; border-top: none; border-radius: 0 0 8px 8px;">
            <h2 style="color: #166534; margin-top: 0;">New Customer Message</h2>
            <p>A customer has sent a new message regarding their return request.</p>
            
            <div style="background-color: #f3f4f6; padding: 16px; border-radius: 8px; margin: 20px 0;">
              <p style="margin: 0;"><strong>Order:</strong> ${orderNumber}</p>
              <p style="margin: 8px 0;"><strong>Customer:</strong> ${customerName} (${customerEmail})</p>
              <p style="margin: 8px 0;"><strong>Return Reason:</strong> ${returnData.reason}</p>
            </div>
            
            <div style="background-color: #dbeafe; padding: 16px; border-radius: 8px; margin: 20px 0;">
              <p style="margin: 0; color: #1e40af;"><strong>Customer Message:</strong></p>
              <p style="margin: 8px 0 0 0; color: #1e3a8a;">${message}</p>
            </div>
            
            <p>Please log in to the admin panel to respond.</p>
          </div>
        </div>
      `;
    }

    // Send email via Resend
    const emailResponse = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${RESEND_API_KEY}`,
      },
      body: JSON.stringify({
        from: "New Sathiya Furniture <onboarding@resend.dev>",
        to: [recipientEmail],
        subject: subject,
        html: htmlContent,
      }),
    });

    const result = await emailResponse.json();

    if (!emailResponse.ok) {
      console.error("Resend API error:", result);
      throw new Error(result.message || "Failed to send email");
    }

    console.log("Return message email sent successfully:", result);

    return new Response(JSON.stringify({ success: true, result }), {
      status: 200,
      headers: { "Content-Type": "application/json", ...corsHeaders },
    });
  } catch (error: any) {
    console.error("Error in send-return-message-email function:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);