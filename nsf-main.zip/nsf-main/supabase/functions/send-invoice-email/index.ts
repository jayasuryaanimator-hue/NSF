import { serve } from "https://deno.land/std@0.190.0/http/server.ts";

const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY");

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

interface OrderItem {
  product_name: string;
  quantity: number;
  unit_price: number;
  total_price: number;
}

interface InvoiceEmailRequest {
  orderId: string;
  orderNumber: string;
  customerName: string;
  customerEmail: string;
  customerPhone?: string;
  items: OrderItem[];
  subtotal: number;
  tax: number;
  shipping: number;
  total: number;
  paymentMethod: string;
  transactionId?: string;
}

const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
  }).format(amount);
};

const generateInvoiceHTML = (data: InvoiceEmailRequest): string => {
  const itemsHTML = data.items.map(item => `
    <tr>
      <td style="padding: 12px; border-bottom: 1px solid #e5e7eb;">${item.product_name}</td>
      <td style="padding: 12px; border-bottom: 1px solid #e5e7eb; text-align: center;">${item.quantity}</td>
      <td style="padding: 12px; border-bottom: 1px solid #e5e7eb; text-align: right;">${formatCurrency(item.unit_price)}</td>
      <td style="padding: 12px; border-bottom: 1px solid #e5e7eb; text-align: right;">${formatCurrency(item.total_price)}</td>
    </tr>
  `).join('');

  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Invoice - ${data.orderNumber}</title>
    </head>
    <body style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 0; padding: 0; background-color: #f3f4f6;">
      <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
        <!-- Header -->
        <div style="background: linear-gradient(135deg, #059669 0%, #047857 100%); color: white; padding: 30px; border-radius: 12px 12px 0 0; text-align: center;">
          <h1 style="margin: 0; font-size: 24px;">New Sathiya Furniture</h1>
          <p style="margin: 10px 0 0 0; opacity: 0.9;">Quality Home Furniture</p>
        </div>
        
        <!-- Payment Confirmation Banner -->
        <div style="background-color: #d1fae5; padding: 20px; text-align: center; border-bottom: 2px solid #059669;">
          <div style="font-size: 48px; margin-bottom: 10px;">✓</div>
          <h2 style="margin: 0; color: #047857;">Payment Verified!</h2>
          <p style="margin: 10px 0 0 0; color: #065f46;">Your order has been confirmed and is being processed.</p>
        </div>
        
        <!-- Main Content -->
        <div style="background-color: white; padding: 30px; border-radius: 0 0 12px 12px; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
          <!-- Customer Info -->
          <div style="margin-bottom: 30px;">
            <h3 style="margin: 0 0 15px 0; color: #1f2937; border-bottom: 2px solid #e5e7eb; padding-bottom: 10px;">Order Details</h3>
            <table style="width: 100%;">
              <tr>
                <td style="padding: 5px 0; color: #6b7280;">Order Number:</td>
                <td style="padding: 5px 0; font-weight: bold; color: #059669;">${data.orderNumber}</td>
              </tr>
              <tr>
                <td style="padding: 5px 0; color: #6b7280;">Customer Name:</td>
                <td style="padding: 5px 0;">${data.customerName}</td>
              </tr>
              <tr>
                <td style="padding: 5px 0; color: #6b7280;">Payment Method:</td>
                <td style="padding: 5px 0;">${data.paymentMethod}</td>
              </tr>
              ${data.transactionId ? `
              <tr>
                <td style="padding: 5px 0; color: #6b7280;">Transaction ID:</td>
                <td style="padding: 5px 0; font-family: monospace;">${data.transactionId}</td>
              </tr>
              ` : ''}
            </table>
          </div>
          
          <!-- Items Table -->
          <div style="margin-bottom: 30px;">
            <h3 style="margin: 0 0 15px 0; color: #1f2937; border-bottom: 2px solid #e5e7eb; padding-bottom: 10px;">Items Ordered</h3>
            <table style="width: 100%; border-collapse: collapse;">
              <thead>
                <tr style="background-color: #f9fafb;">
                  <th style="padding: 12px; text-align: left; border-bottom: 2px solid #e5e7eb;">Product</th>
                  <th style="padding: 12px; text-align: center; border-bottom: 2px solid #e5e7eb;">Qty</th>
                  <th style="padding: 12px; text-align: right; border-bottom: 2px solid #e5e7eb;">Price</th>
                  <th style="padding: 12px; text-align: right; border-bottom: 2px solid #e5e7eb;">Total</th>
                </tr>
              </thead>
              <tbody>
                ${itemsHTML}
              </tbody>
            </table>
          </div>
          
          <!-- Order Summary -->
          <div style="background-color: #f9fafb; padding: 20px; border-radius: 8px; margin-bottom: 30px;">
            <table style="width: 100%;">
              <tr>
                <td style="padding: 8px 0; color: #6b7280;">Subtotal:</td>
                <td style="padding: 8px 0; text-align: right;">${formatCurrency(data.subtotal)}</td>
              </tr>
              <tr>
                <td style="padding: 8px 0; color: #6b7280;">GST (18%):</td>
                <td style="padding: 8px 0; text-align: right;">${formatCurrency(data.tax)}</td>
              </tr>
              <tr>
                <td style="padding: 8px 0; color: #6b7280;">Shipping:</td>
                <td style="padding: 8px 0; text-align: right;">${data.shipping === 0 ? '<span style="color: #059669;">FREE</span>' : formatCurrency(data.shipping)}</td>
              </tr>
              <tr style="border-top: 2px solid #e5e7eb;">
                <td style="padding: 12px 0; font-weight: bold; font-size: 18px;">Total Paid:</td>
                <td style="padding: 12px 0; text-align: right; font-weight: bold; font-size: 18px; color: #059669;">${formatCurrency(data.total)}</td>
              </tr>
            </table>
          </div>
          
          <!-- What's Next -->
          <div style="background-color: #eff6ff; padding: 20px; border-radius: 8px; margin-bottom: 30px; border-left: 4px solid #3b82f6;">
            <h4 style="margin: 0 0 10px 0; color: #1e40af;">What's Next?</h4>
            <ol style="margin: 0; padding-left: 20px; color: #1e3a8a;">
              <li style="margin-bottom: 8px;">Your order is being prepared</li>
              <li style="margin-bottom: 8px;">You'll receive delivery updates via SMS/WhatsApp</li>
              <li>Expected delivery: 7-14 business days</li>
            </ol>
          </div>
          
          <!-- Contact -->
          <div style="text-align: center; padding-top: 20px; border-top: 1px solid #e5e7eb;">
            <p style="color: #6b7280; margin: 0 0 10px 0;">Need help? Contact us:</p>
            <p style="margin: 5px 0;">
              <a href="tel:+918675255084" style="color: #059669; text-decoration: none;">📞 +91 86752 55084</a>
            </p>
            <p style="margin: 5px 0;">
              <a href="mailto:krameshjet@gmail.com" style="color: #059669; text-decoration: none;">✉️ krameshjet@gmail.com</a>
            </p>
            <p style="margin: 15px 0 0 0;">
              <a href="https://wa.me/918675255084" style="display: inline-block; background-color: #25D366; color: white; padding: 10px 20px; border-radius: 6px; text-decoration: none;">
                💬 Chat on WhatsApp
              </a>
            </p>
          </div>
        </div>
        
        <!-- Footer -->
        <div style="text-align: center; padding: 20px; color: #9ca3af; font-size: 12px;">
          <p style="margin: 0;">New Sathiya Furniture</p>
          <p style="margin: 5px 0;">39c, Aavanipudur Jalakandapuram, Main Road</p>
          <p style="margin: 5px 0;">Edappadi, Tamil Nadu 637101</p>
          <p style="margin: 10px 0 0 0;">© ${new Date().getFullYear()} New Sathiya Furniture. All rights reserved.</p>
        </div>
      </div>
    </body>
    </html>
  `;
};

const handler = async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const data: InvoiceEmailRequest = await req.json();

    if (!data.customerEmail) {
      return new Response(
        JSON.stringify({ error: "Customer email is required" }),
        {
          status: 400,
          headers: { "Content-Type": "application/json", ...corsHeaders },
        }
      );
    }

    if (!RESEND_API_KEY) {
      console.log("RESEND_API_KEY not configured, skipping email");
      return new Response(
        JSON.stringify({ message: "Email service not configured" }),
        {
          status: 200,
          headers: { "Content-Type": "application/json", ...corsHeaders },
        }
      );
    }

    // Use Resend's default domain for testing, switch to custom domain once verified
    const fromAddress = "New Sathiya Furniture <onboarding@resend.dev>";
    
    const emailResponse = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${RESEND_API_KEY}`,
      },
      body: JSON.stringify({
        from: fromAddress,
        to: [data.customerEmail],
        subject: `Order Confirmed - ${data.orderNumber} | New Sathiya Furniture`,
        html: generateInvoiceHTML(data),
      }),
    });

    const result = await emailResponse.json();

    if (!emailResponse.ok) {
      console.error("Resend API error:", result);
      throw new Error(result.message || "Failed to send email");
    }

    console.log("Invoice email sent successfully:", result);

    return new Response(JSON.stringify(result), {
      status: 200,
      headers: {
        "Content-Type": "application/json",
        ...corsHeaders,
      },
    });
  } catch (error: any) {
    console.error("Error in send-invoice-email function:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);