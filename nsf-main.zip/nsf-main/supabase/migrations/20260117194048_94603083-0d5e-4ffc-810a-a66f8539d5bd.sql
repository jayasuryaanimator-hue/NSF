-- Create gallery_items table for custom project showcase
CREATE TABLE public.gallery_items (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  category TEXT NOT NULL,
  image_url TEXT NOT NULL,
  description TEXT,
  wood_type TEXT,
  dimensions TEXT,
  is_featured BOOLEAN DEFAULT false,
  display_order INTEGER DEFAULT 0,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.gallery_items ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Anyone can view active gallery items"
ON public.gallery_items
FOR SELECT
USING (is_active = true);

CREATE POLICY "Admins can view all gallery items"
ON public.gallery_items
FOR SELECT
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can manage gallery items"
ON public.gallery_items
FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role));

-- Create trigger for updated_at
CREATE TRIGGER update_gallery_items_updated_at
BEFORE UPDATE ON public.gallery_items
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Insert initial gallery items
INSERT INTO public.gallery_items (title, category, image_url, description, wood_type, dimensions, display_order) VALUES
('Custom Engraved Anniversary Board', 'Cutting Boards', '/src/assets/gallery/custom-engraved-board.jpg', 'A personalized cutting board with custom engraving for a couple''s 25th anniversary', 'Teak', '18" x 12" x 1.5"', 1),
('Live Edge Serving Platter', 'Serving Platters', '/src/assets/gallery/live-edge-platter.jpg', 'Natural live edge serving platter preserving the organic beauty of the wood grain', 'Walnut', '24" x 10" x 1"', 2),
('Hexagon Coaster Set', 'Coasters', '/src/assets/gallery/hexagon-coasters.jpg', 'Set of 6 geometric hexagon coasters with natural wood finish', 'Mixed Hardwoods', '4" diameter each', 3),
('Professional Butcher Block', 'Cutting Boards', '/src/assets/gallery/butcher-block.jpg', 'Heavy-duty end-grain butcher block for professional kitchen use', 'Maple', '20" x 16" x 3"', 4),
('Wedding Gift Set', 'Gift Sets', '/src/assets/gallery/wedding-gift-set.jpg', 'Custom wedding gift set with personalized board, serving utensils, and coasters', 'Teak', 'Various sizes', 5),
('Cheese Board with Hidden Drawer', 'Serving Platters', '/src/assets/gallery/cheese-board-drawer.jpg', 'Elegant cheese board featuring a hidden drawer for cheese knives', 'Acacia', '16" x 8" x 2"', 6);