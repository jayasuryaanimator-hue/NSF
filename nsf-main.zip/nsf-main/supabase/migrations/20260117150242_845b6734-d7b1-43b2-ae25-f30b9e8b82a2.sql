-- Create role_audit_log table to track all role changes
CREATE TABLE public.role_audit_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  target_user_id UUID NOT NULL,
  changed_by_user_id UUID NOT NULL,
  old_role app_role,
  new_role app_role NOT NULL,
  action TEXT NOT NULL CHECK (action IN ('assigned', 'changed', 'removed')),
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Add index for faster lookups
CREATE INDEX idx_role_audit_log_target_user ON public.role_audit_log(target_user_id);
CREATE INDEX idx_role_audit_log_changed_by ON public.role_audit_log(changed_by_user_id);
CREATE INDEX idx_role_audit_log_created_at ON public.role_audit_log(created_at DESC);

-- Enable RLS
ALTER TABLE public.role_audit_log ENABLE ROW LEVEL SECURITY;

-- Only admins can view and insert audit logs
CREATE POLICY "Admins can view role audit logs"
  ON public.role_audit_log
  FOR SELECT
  USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can create role audit logs"
  ON public.role_audit_log
  FOR INSERT
  WITH CHECK (has_role(auth.uid(), 'admin'));