-- Add slug column to branches table for URL-friendly identifiers
ALTER TABLE public.branches ADD COLUMN IF NOT EXISTS slug TEXT;

-- Create unique index on slug
CREATE UNIQUE INDEX IF NOT EXISTS idx_branches_slug ON public.branches(slug) WHERE slug IS NOT NULL;

-- Update existing branches with slugs based on their code (lowercase)
UPDATE public.branches 
SET slug = LOWER(REPLACE(code, ' ', '-'))
WHERE slug IS NULL;

-- Add NOT NULL constraint after populating data (commented out to allow flexibility)
-- ALTER TABLE public.branches ALTER COLUMN slug SET NOT NULL;