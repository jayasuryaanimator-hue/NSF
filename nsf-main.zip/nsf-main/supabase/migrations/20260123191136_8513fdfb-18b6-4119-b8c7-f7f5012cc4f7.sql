-- Create custom_order_messages table for conversations
CREATE TABLE public.custom_order_messages (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  custom_order_id UUID NOT NULL REFERENCES public.custom_orders(id) ON DELETE CASCADE,
  sender_type TEXT NOT NULL CHECK (sender_type IN ('customer', 'admin')),
  sender_id UUID NOT NULL,
  message TEXT NOT NULL CHECK (char_length(message) <= 1000),
  is_read BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Add soft-delete columns to custom_orders
ALTER TABLE public.custom_orders
ADD COLUMN deleted_by_customer BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN deleted_by_admin BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN customer_deleted_at TIMESTAMP WITH TIME ZONE,
ADD COLUMN admin_deleted_at TIMESTAMP WITH TIME ZONE;

-- Enable RLS on custom_order_messages
ALTER TABLE public.custom_order_messages ENABLE ROW LEVEL SECURITY;

-- Customers can view messages for their own orders
CREATE POLICY "Customers can view their order messages"
ON public.custom_order_messages
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM public.custom_orders
    WHERE custom_orders.id = custom_order_messages.custom_order_id
    AND custom_orders.user_id = auth.uid()
  )
);

-- Customers can insert messages for their own orders
CREATE POLICY "Customers can send messages on their orders"
ON public.custom_order_messages
FOR INSERT
WITH CHECK (
  sender_type = 'customer'
  AND sender_id = auth.uid()
  AND EXISTS (
    SELECT 1 FROM public.custom_orders
    WHERE custom_orders.id = custom_order_messages.custom_order_id
    AND custom_orders.user_id = auth.uid()
  )
);

-- Admins can view all messages
CREATE POLICY "Admins can view all messages"
ON public.custom_order_messages
FOR SELECT
USING (has_role(auth.uid(), 'admin'::app_role));

-- Admins can insert messages
CREATE POLICY "Admins can send messages"
ON public.custom_order_messages
FOR INSERT
WITH CHECK (
  sender_type = 'admin'
  AND has_role(auth.uid(), 'admin'::app_role)
);

-- Admins can update messages (mark as read)
CREATE POLICY "Admins can update messages"
ON public.custom_order_messages
FOR UPDATE
USING (has_role(auth.uid(), 'admin'::app_role));

-- Admins can delete messages
CREATE POLICY "Admins can delete messages"
ON public.custom_order_messages
FOR DELETE
USING (has_role(auth.uid(), 'admin'::app_role));

-- Allow customers to delete their own orders (hard delete)
CREATE POLICY "Customers can delete their own orders"
ON public.custom_orders
FOR DELETE
USING (auth.uid() = user_id);

-- Allow customers to update their own orders
CREATE POLICY "Customers can update their own orders"
ON public.custom_orders
FOR UPDATE
USING (auth.uid() = user_id);