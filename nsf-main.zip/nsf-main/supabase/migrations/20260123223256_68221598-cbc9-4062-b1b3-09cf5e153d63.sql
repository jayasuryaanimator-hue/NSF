-- Recreate views with security_invoker=on to fix the security definer warning
DROP VIEW IF EXISTS public.branch_stock_summary;
DROP VIEW IF EXISTS public.branch_billing_summary;
DROP VIEW IF EXISTS public.branch_quotations_summary;
DROP VIEW IF EXISTS public.branch_orders_summary;

CREATE VIEW public.branch_stock_summary 
WITH (security_invoker=on) AS
SELECT 
  b.id as branch_id,
  b.name as branch_name,
  b.code as branch_code,
  COUNT(p.id) as total_products,
  COALESCE(SUM(p.stock_quantity), 0) as total_units,
  COALESCE(SUM(COALESCE(p.cost_price, p.price) * COALESCE(p.stock_quantity, 0)), 0) as total_cost_value,
  COALESCE(SUM(p.price * COALESCE(p.stock_quantity, 0)), 0) as total_retail_value,
  COUNT(CASE WHEN COALESCE(p.stock_quantity, 0) = 0 THEN 1 END) as out_of_stock_count,
  COUNT(CASE WHEN COALESCE(p.stock_quantity, 0) > 0 AND COALESCE(p.stock_quantity, 0) <= 5 THEN 1 END) as low_stock_count
FROM public.branches b
LEFT JOIN public.products p ON p.branch_id = b.id AND p.is_active = true
WHERE b.is_active = true
GROUP BY b.id, b.name, b.code;

CREATE VIEW public.branch_billing_summary 
WITH (security_invoker=on) AS
SELECT 
  b.id as branch_id,
  b.name as branch_name,
  b.code as branch_code,
  COUNT(br.id) as total_bills,
  COALESCE(SUM(br.total_amount), 0) as total_amount,
  COALESCE(SUM(br.subtotal), 0) as total_subtotal,
  COALESCE(SUM(br.tax_amount), 0) as total_tax,
  COALESCE(SUM(br.discount_amount), 0) as total_discounts
FROM public.branches b
LEFT JOIN public.billing_records br ON br.branch_id = b.id
WHERE b.is_active = true
GROUP BY b.id, b.name, b.code;

CREATE VIEW public.branch_quotations_summary 
WITH (security_invoker=on) AS
SELECT 
  b.id as branch_id,
  b.name as branch_name,
  b.code as branch_code,
  COUNT(q.id) as total_quotations,
  COUNT(CASE WHEN q.status = 'draft' THEN 1 END) as draft_count,
  COUNT(CASE WHEN q.status = 'sent' THEN 1 END) as sent_count,
  COUNT(CASE WHEN q.status = 'accepted' THEN 1 END) as accepted_count,
  COUNT(CASE WHEN q.status = 'rejected' THEN 1 END) as rejected_count,
  COALESCE(SUM(q.total_amount), 0) as total_value
FROM public.branches b
LEFT JOIN public.quotations q ON q.branch_id = b.id
WHERE b.is_active = true
GROUP BY b.id, b.name, b.code;

CREATE VIEW public.branch_orders_summary 
WITH (security_invoker=on) AS
SELECT 
  b.id as branch_id,
  b.name as branch_name,
  b.code as branch_code,
  COUNT(o.id) as total_orders,
  COUNT(CASE WHEN o.status = 'delivered' THEN 1 END) as delivered_count,
  COUNT(CASE WHEN o.status NOT IN ('delivered', 'cancelled') THEN 1 END) as pending_count,
  COUNT(CASE WHEN o.status = 'cancelled' THEN 1 END) as cancelled_count,
  COALESCE(SUM(CASE WHEN o.status = 'delivered' AND o.payment_status = 'verified' THEN o.total_amount ELSE 0 END), 0) as total_sales
FROM public.branches b
LEFT JOIN public.orders o ON o.branch_id = b.id
WHERE b.is_active = true
GROUP BY b.id, b.name, b.code;