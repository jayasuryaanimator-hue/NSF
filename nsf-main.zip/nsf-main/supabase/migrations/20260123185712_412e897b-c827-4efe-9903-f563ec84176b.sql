-- Add GSTIN columns to billing_records and quotations tables

-- Add GSTIN to billing_records
ALTER TABLE public.billing_records 
ADD COLUMN IF NOT EXISTS customer_gstin text NULL;

-- Add GSTIN to quotations
ALTER TABLE public.quotations 
ADD COLUMN IF NOT EXISTS customer_gstin text NULL;