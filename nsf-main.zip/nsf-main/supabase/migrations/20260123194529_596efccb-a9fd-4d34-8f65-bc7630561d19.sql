-- Enable realtime for return_messages table
ALTER PUBLICATION supabase_realtime ADD TABLE public.return_messages;