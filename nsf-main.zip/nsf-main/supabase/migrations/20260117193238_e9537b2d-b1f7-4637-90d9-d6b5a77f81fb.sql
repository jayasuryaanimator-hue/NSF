-- Create storage bucket for custom order reference images
INSERT INTO storage.buckets (id, name, public) 
VALUES ('custom-order-images', 'custom-order-images', true)
ON CONFLICT (id) DO NOTHING;

-- Storage policies for custom order images
CREATE POLICY "Anyone can upload custom order images"
ON storage.objects
FOR INSERT
WITH CHECK (bucket_id = 'custom-order-images');

CREATE POLICY "Anyone can view custom order images"
ON storage.objects
FOR SELECT
USING (bucket_id = 'custom-order-images');

CREATE POLICY "Admins can delete custom order images"
ON storage.objects
FOR DELETE
USING (bucket_id = 'custom-order-images' AND has_role(auth.uid(), 'admin'::app_role));