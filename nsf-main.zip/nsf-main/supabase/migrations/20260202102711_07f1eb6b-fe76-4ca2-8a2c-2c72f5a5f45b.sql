-- Stock Transfer Status Enum
CREATE TYPE public.stock_transfer_status AS ENUM (
  'requested',
  'challan_created',
  'approved',
  'in_transit',
  'received',
  'completed',
  'rejected'
);

-- Stock Transfers Table
CREATE TABLE public.stock_transfers (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  transfer_number TEXT NOT NULL UNIQUE,
  from_branch_id UUID NOT NULL REFERENCES public.branches(id),
  to_branch_id UUID NOT NULL REFERENCES public.branches(id),
  requested_by UUID NOT NULL,
  approved_by UUID,
  status stock_transfer_status NOT NULL DEFAULT 'requested',
  notes TEXT,
  requested_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  challan_created_at TIMESTAMP WITH TIME ZONE,
  approved_at TIMESTAMP WITH TIME ZONE,
  shipped_at TIMESTAMP WITH TIME ZONE,
  received_at TIMESTAMP WITH TIME ZONE,
  completed_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  CONSTRAINT different_branches CHECK (from_branch_id != to_branch_id)
);

-- Stock Transfer Items Table
CREATE TABLE public.stock_transfer_items (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  transfer_id UUID NOT NULL REFERENCES public.stock_transfers(id) ON DELETE CASCADE,
  product_id UUID NOT NULL REFERENCES public.products(id),
  requested_quantity INTEGER NOT NULL CHECK (requested_quantity > 0),
  sent_quantity INTEGER,
  received_quantity INTEGER,
  damaged_quantity INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Damaged Stock Table
CREATE TABLE public.damaged_stock (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  transfer_item_id UUID NOT NULL REFERENCES public.stock_transfer_items(id),
  product_id UUID NOT NULL REFERENCES public.products(id),
  branch_id UUID NOT NULL REFERENCES public.branches(id),
  from_branch_id UUID NOT NULL REFERENCES public.branches(id),
  quantity INTEGER NOT NULL CHECK (quantity > 0),
  damage_notes TEXT,
  recorded_by UUID NOT NULL,
  recorded_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Transfer Challan Table
CREATE TABLE public.transfer_challans (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  challan_number TEXT NOT NULL UNIQUE,
  transfer_id UUID NOT NULL REFERENCES public.stock_transfers(id),
  created_by UUID NOT NULL,
  signed_by UUID,
  vehicle_number TEXT,
  driver_name TEXT,
  driver_phone TEXT,
  dispatch_date TIMESTAMP WITH TIME ZONE,
  expected_delivery_date TIMESTAMP WITH TIME ZONE,
  actual_delivery_date TIMESTAMP WITH TIME ZONE,
  signature_data TEXT,
  is_signed BOOLEAN DEFAULT FALSE,
  signed_at TIMESTAMP WITH TIME ZONE,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE public.stock_transfers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.stock_transfer_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.damaged_stock ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.transfer_challans ENABLE ROW LEVEL SECURITY;

-- RLS Policies for stock_transfers
CREATE POLICY "Admins can manage all transfers" 
ON public.stock_transfers FOR ALL 
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Branch managers can view transfers involving their branch" 
ON public.stock_transfers FOR SELECT 
USING (
  is_branch_manager(auth.uid(), from_branch_id) OR 
  is_branch_manager(auth.uid(), to_branch_id)
);

CREATE POLICY "Branch managers can create transfer requests from their branch" 
ON public.stock_transfers FOR INSERT 
WITH CHECK (is_branch_manager(auth.uid(), to_branch_id));

CREATE POLICY "Branch managers can update transfers they're involved in" 
ON public.stock_transfers FOR UPDATE 
USING (
  is_branch_manager(auth.uid(), from_branch_id) OR 
  is_branch_manager(auth.uid(), to_branch_id)
);

-- RLS Policies for stock_transfer_items
CREATE POLICY "Admins can manage all transfer items" 
ON public.stock_transfer_items FOR ALL 
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Branch managers can view their transfer items" 
ON public.stock_transfer_items FOR SELECT 
USING (
  EXISTS (
    SELECT 1 FROM public.stock_transfers st 
    WHERE st.id = transfer_id 
    AND (is_branch_manager(auth.uid(), st.from_branch_id) OR is_branch_manager(auth.uid(), st.to_branch_id))
  )
);

CREATE POLICY "Branch managers can insert transfer items for their requests" 
ON public.stock_transfer_items FOR INSERT 
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.stock_transfers st 
    WHERE st.id = transfer_id 
    AND is_branch_manager(auth.uid(), st.to_branch_id)
  )
);

CREATE POLICY "Branch managers can update transfer items" 
ON public.stock_transfer_items FOR UPDATE 
USING (
  EXISTS (
    SELECT 1 FROM public.stock_transfers st 
    WHERE st.id = transfer_id 
    AND (is_branch_manager(auth.uid(), st.from_branch_id) OR is_branch_manager(auth.uid(), st.to_branch_id))
  )
);

-- RLS Policies for damaged_stock
CREATE POLICY "Admins can manage all damaged stock" 
ON public.damaged_stock FOR ALL 
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Branch managers can view damaged stock in their branch" 
ON public.damaged_stock FOR SELECT 
USING (is_branch_manager(auth.uid(), branch_id));

CREATE POLICY "Branch managers can record damaged stock in their branch" 
ON public.damaged_stock FOR INSERT 
WITH CHECK (is_branch_manager(auth.uid(), branch_id));

-- RLS Policies for transfer_challans
CREATE POLICY "Admins can manage all challans" 
ON public.transfer_challans FOR ALL 
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Branch managers can view challans for their transfers" 
ON public.transfer_challans FOR SELECT 
USING (
  EXISTS (
    SELECT 1 FROM public.stock_transfers st 
    WHERE st.id = transfer_id 
    AND (is_branch_manager(auth.uid(), st.from_branch_id) OR is_branch_manager(auth.uid(), st.to_branch_id))
  )
);

CREATE POLICY "Branch managers can create challans for transfers from their branch" 
ON public.transfer_challans FOR INSERT 
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.stock_transfers st 
    WHERE st.id = transfer_id 
    AND is_branch_manager(auth.uid(), st.from_branch_id)
  )
);

CREATE POLICY "Branch managers can update challans for their branch" 
ON public.transfer_challans FOR UPDATE 
USING (
  EXISTS (
    SELECT 1 FROM public.stock_transfers st 
    WHERE st.id = transfer_id 
    AND is_branch_manager(auth.uid(), st.from_branch_id)
  )
);

-- Functions for auto-generating numbers
CREATE OR REPLACE FUNCTION public.generate_transfer_number()
RETURNS TRIGGER AS $$
BEGIN
  NEW.transfer_number = 'TRF-' || TO_CHAR(NOW(), 'YYYYMMDD') || '-' || 
    LPAD(FLOOR(RANDOM() * 10000)::TEXT, 4, '0');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

CREATE OR REPLACE FUNCTION public.generate_challan_number()
RETURNS TRIGGER AS $$
BEGIN
  NEW.challan_number = 'CHN-' || TO_CHAR(NOW(), 'YYYYMMDD') || '-' || 
    LPAD(FLOOR(RANDOM() * 10000)::TEXT, 4, '0');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- Triggers for auto-generating numbers
CREATE TRIGGER set_transfer_number
  BEFORE INSERT ON public.stock_transfers
  FOR EACH ROW
  EXECUTE FUNCTION public.generate_transfer_number();

CREATE TRIGGER set_challan_number
  BEFORE INSERT ON public.transfer_challans
  FOR EACH ROW
  EXECUTE FUNCTION public.generate_challan_number();

-- Trigger for updated_at
CREATE TRIGGER update_stock_transfers_updated_at
  BEFORE UPDATE ON public.stock_transfers
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_transfer_challans_updated_at
  BEFORE UPDATE ON public.transfer_challans
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();